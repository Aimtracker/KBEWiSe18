package de.htw.ai.kbe.servlet.utils;

import de.htw.ai.kbe.servlet.pojo.Song;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TestUtils {

    public static void assertSong(Song song, int id, String artist, String album, String title, int released) {
        assertEquals(artist, song.getArtist());
        assertEquals(album, song.getAlbum());
        assertEquals(id, song.getId().intValue());
        assertEquals(title, song.getTitle());
        assertEquals(released, song.getReleased().intValue());
    }

    public static List<Song> getTestSongs() {
        List<Song> songList = new ArrayList<>();

        Song song1 = new Song();
        songList.add(song1);

        song1.setAlbum("Lateralus");
        song1.setArtist("Tool");
        song1.setId(1);
        song1.setReleased(2001);
        song1.setTitle("Ticks And Leeches");

        Song song2 = new Song();
        songList.add(song2);

        song2.setAlbum("Jar Of Flies");
        song2.setArtist("Alice In Chains");
        song2.setId(2);
        song2.setReleased(1994);
        song2.setTitle("Rotten Apple");

        return songList;
    }

    public static Song getTestSong() {
        Song song = new Song();
        song.setId(3);
        song.setArtist("Jimi Hendrix");
        song.setAlbum("Axis: Bold As Love");
        song.setTitle("Little Wing");
        song.setReleased(1967);
        return song;
    }

    public static String getJsonPayload() {
        return "{\n  \"title\" : \"Little Wing\",\n  \"artist\" : \"Jimi Hendrixx\",\n  \"album\" : \"Axis: Bold As Love\",\n  \"released\" : 1967\n}";
    }

}
